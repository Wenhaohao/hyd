资源文件目录





Public/js/require.js    --  RequireJS asynchronous load  js
Public/css/common/normalize.css  -- 标准化 css
Public/css/common/style.css    --　web common stylesheet

Public/css/common/tools/logo.png  --  web logo
Public/css/libs                 -- 存放外部库文件
Public/images/default-user.png  -- 用户默认头像


index.html              --  home page
