require.config({
	baseUrl:"/Public/Home/js/lib",  //基本url 地址
	paths:{
		validForm:"../app/validForm",
		flicker:"../app/flicker",
	}
});
// 加载必要 js 文件
require(["jquery","bootstrap"],function (){

});



